public interface IAnimal {
  String sound();
}